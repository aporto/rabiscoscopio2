# This script imports a series of animation frames and join them,
# creating a single animation file
#
# All animations must be WAV files created by Rabiscoscopio.
#
#
# Notes:
# 1 - Draw each animation frame as a separated SVG file, and use Rabiscoscopio
# to convert all images into a set of WAV files
#
# 2 - Set 'Duration of file' on Rabiscoscopio to a small number (usually 0.1 or
# 0.05), so the frame WAV file will take only the necessary time to show the
# frame on oscilloscope
#
# 3 - Put all your WAV files into a single folder. This script will process
# all WAV files found at that folder

# Configure these two options according to your animation
# Select the duration of animation
animation_length_seconds = 10

# Select the path where your animation frames are saved
images_path = "images/electroBOOM/eyebrow"

# don't change anything from here below

import wave, os

infiles = []
for f in os.listdir(images_path):
    infile = os.path.join(images_path, f)
    filename, ext = os.path.splitext(infile)
    if ext.lower() == '.wav':
        infiles.append(infile)

if len(infiles) == 0:
    print "Error. No WAV file found at",images_path
    pass

outfile = os.path.split(images_path)[1]
outfile = "joined_" + outfile + ".wav"
outfile = os.path.join(images_path, outfile)

data= []
duration = 0.0
for infile in infiles:
    print ">> Importing", infile
    w = wave.open(infile, 'rb')
    data.append( [w.getparams(), w.readframes(w.getnframes())] )

    frames = w.getnframes()
    rate = w.getframerate()
    duration += float(frames) / float(rate)
    w.close()

repeat = int(float(animation_length_seconds) / duration)

output = wave.open(outfile, 'wb')
output.setparams(data[0][0])
for i in range(repeat):
    output.writeframes(data[0][1])
    output.writeframes(data[1][1])
output.close()
print ">> Done! File generated:", outfile